# Copyright (c) 2015-present, Facebook, Inc.
# All rights reserved.
from models import *

dependencies = ["torch", "torchvision", "timm"]
