#!/usr/bin/env bash
export NCCL_LL_THRESHOLD=0

CONFIG=$1
GPUS=$2
PORT=${PORT:-6666}

python -m torch.distributed.launch --nproc_per_node=4 --master_port=1234 --use_env main.py --config /home/r12user3/Documents/PVT/classification/configs/pvt_v2/pvt_v2_b0.py --data-path /home/r12user3/Documents/imagenet
